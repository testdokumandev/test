﻿using Microsoft.Web.Services3;
using Microsoft.Web.Services3.Security.Tokens;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Security;
using System.Xml;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WsCall
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            txtURI.Text = "https://extws-dt.teb.com.tr:443/caykurdbs/CaykurDBSWS";
            txtUsername.Text = "caykurdbs";
            txtPassword.Text = "12345678";
            txtInput.Text = PrepareInputParameter();
            XmlDocument login = new XmlDocument();
            login.LoadXml(PrepareInputParameter());
            System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            try
            {
                
                txtOutput.Text = string.Empty;

                var _service = new CaykurDBS.CaykurExternalService();
                _service.Url = txtURI.Text;

                string _userName = txtUsername.Text;
                string _password = txtPassword.Text;

                UsernameToken _token = new UsernameToken(_userName, _password, PasswordOption.SendPlainText);
                SoapContext _requestContext = _service.RequestSoapContext;
                _requestContext.Security.Timestamp.TtlInSeconds = 60;
                _requestContext.Security.MustUnderstand = false;
                _requestContext.Security.Tokens.Add(_token);
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(PrepareInputParameter());
                string result = "";
                result = _service.KurumOnlineDBS(doc.OuterXml);

                txtOutput.Text = result;
            }
            catch (Exception ex)
            {
                txtOutput.Text = ex.Message + Environment.NewLine + ex.StackTrace;
            }
        }

        private string PrepareInputParameter()
        {
            StringBuilder _builder = new StringBuilder();

            _builder.AppendLine("<string>");
            _builder.AppendLine(" <Input>");
            _builder.AppendLine("  <BankaKurumKodu>CAYKUR</BankaKurumKodu>");
            _builder.AppendLine("<BankaKullanici >caykurdbs</BankaKullanici >");
            _builder.AppendLine("<BankaSifre>12345678</BankaSifre>");
            _builder.AppendLine("  <Data>");
            _builder.AppendLine("   <Limit>");
            _builder.AppendLine("    <AboneNo>555</AboneNo>");
            _builder.AppendLine("    <BolgeKodu>02</BolgeKodu>");
            _builder.AppendLine("    <BankaIslemKodu>LimitSorgula</BankaIslemKodu>");
            _builder.AppendLine("    <DovizCinsi>TL</DovizCinsi>");
            _builder.AppendLine("   </Limit>");
            _builder.AppendLine("  </Data>");
            _builder.AppendLine(" </Input>");
            _builder.AppendLine("</string>");

            return _builder.ToString();
        }
    }
}
